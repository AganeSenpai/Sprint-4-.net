﻿using Microsoft.AspNetCore.Mvc;
using OdontoSinistro.Application.Interfaces;
using OdontoSinistro.Domain.Entities;

namespace OdontoSinistro.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FuncionarioController : ControllerBase
    {
        private readonly IFuncionarioService _funcionarioService;

        public FuncionarioController(IFuncionarioService funcionarioService)
        {
            _funcionarioService = funcionarioService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Funcionario>>> GetAll()
        {
            var funcionarios = await _funcionarioService.GetAllAsync();
            return Ok(funcionarios);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Funcionario>> GetById(long id)
        {
            var funcionario = await _funcionarioService.GetByIdAsync(id);
            if (funcionario == null) return NotFound();
            return Ok(funcionario);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Funcionario funcionario)
        {
            await _funcionarioService.AddAsync(funcionario);
            return CreatedAtAction(nameof(GetById), new { id = funcionario.Id }, funcionario);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(long id, Funcionario funcionario)
        {
            if (id != funcionario.Id) return BadRequest();
            await _funcionarioService.UpdateAsync(funcionario);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(long id)
        {
            await _funcionarioService.DeleteAsync(id);
            return NoContent();
        }
    }
}
