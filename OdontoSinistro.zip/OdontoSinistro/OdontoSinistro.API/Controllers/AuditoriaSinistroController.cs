﻿using Microsoft.AspNetCore.Mvc;
using OdontoSinistro.Application.Interfaces;
using OdontoSinistro.Domain.Entities;

namespace OdontoSinistro.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuditoriaSinistroController : ControllerBase
    {
        private readonly IAuditoriaSinistroService _auditoriaSinistroService;

        public AuditoriaSinistroController(IAuditoriaSinistroService auditoriaSinistroService)
        {
            _auditoriaSinistroService = auditoriaSinistroService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<AuditoriaSinistro>>> GetAll()
        {
            var auditorias = await _auditoriaSinistroService.GetAllAsync();
            return Ok(auditorias);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<AuditoriaSinistro>> GetById(long id)
        {
            var auditoria = await _auditoriaSinistroService.GetByIdAsync(id);
            if (auditoria == null) return NotFound();
            return Ok(auditoria);
        }

        [HttpPost]
        public async Task<IActionResult> Create(AuditoriaSinistro auditoria)
        {
            await _auditoriaSinistroService.AddAsync(auditoria);
            return CreatedAtAction(nameof(GetById), new { id = auditoria.Id }, auditoria);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(long id, AuditoriaSinistro auditoria)
        {
            if (id != auditoria.Id) return BadRequest();
            await _auditoriaSinistroService.UpdateAsync(auditoria);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(long id)
        {
            await _auditoriaSinistroService.DeleteAsync(id);
            return NoContent();
        }
    }
}
