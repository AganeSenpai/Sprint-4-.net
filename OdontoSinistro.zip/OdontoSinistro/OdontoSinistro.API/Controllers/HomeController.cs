﻿using Microsoft.AspNetCore.Mvc;
using OdontoSinistro.Application.Services;

namespace OdontoSinistro.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SentimentoController : ControllerBase
{
    private readonly SentimentoService _sentimentoService;

    public SentimentoController(SentimentoService sentimentoService)
    {
        _sentimentoService = sentimentoService;
    }

    [HttpPost("analise-sentimento")]
    public IActionResult AnalisarDescricao([FromBody] string descricao)
    {
        var sentimento = _sentimentoService.AnalisarDescricao(descricao);
        return Ok(new { sentimento });
    }
}

