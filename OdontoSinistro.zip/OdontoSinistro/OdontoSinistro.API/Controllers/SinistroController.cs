﻿using Microsoft.AspNetCore.Mvc;
using OdontoSinistro.Application.Interfaces;
using OdontoSinistro.Domain.Entities;
using OdontoSinistro.Domain.ML;

namespace OdontoSinistro.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SinistroController : ControllerBase
{
    private readonly ISinistroService _sinistroService;
    private readonly IFraudeService _fraudeService;

    public SinistroController(ISinistroService sinistroService, IFraudeService fraudeService)
    {
        _sinistroService = sinistroService;
        _fraudeService = fraudeService;
    }

    // GET: api/sinistro
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Sinistro>>> GetAll()
    {
        var sinistros = await _sinistroService.GetAllAsync();
        return Ok(sinistros);
    }

    // GET: api/sinistro/{id}
    [HttpGet("{id}")]
    public async Task<ActionResult<Sinistro>> GetById(long id)
    {
        var sinistro = await _sinistroService.GetByIdAsync(id);
        if (sinistro == null)
            return NotFound();

        return Ok(sinistro);
    }

    // POST: api/sinistro
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] Sinistro sinistro)
    {
        await _sinistroService.AddAsync(sinistro);
        return CreatedAtAction(nameof(GetById), new { id = sinistro.Id }, sinistro);
    }

    // PUT: api/sinistro/{id}
    [HttpPut("{id}")]
    public async Task<IActionResult> Update(long id, [FromBody] Sinistro sinistro)
    {
        if (id != sinistro.Id)
            return BadRequest("ID do parâmetro não confere com o objeto informado.");

        await _sinistroService.UpdateAsync(sinistro);
        return NoContent();
    }

    // DELETE: api/sinistro/{id}
    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(long id)
    {
        await _sinistroService.DeleteAsync(id);
        return NoContent();
    }

    // POST: api/sinistro/prever-fraude
    [HttpPost("prever-fraude")]
    public IActionResult PreverFraude([FromBody] SinistroFraudeModel input)
    {
        var resultado = _fraudeService.PreverFraude(input.ValorReclamado, input.TipoProcedimento);
        return Ok(new { fraudeSuspeita = resultado });
    }
}


