﻿using Microsoft.AspNetCore.Mvc;
using OdontoSinistro.Application.Interfaces;
using OdontoSinistro.Domain.Entities;

namespace OdontoSinistro.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class DentistaController : ControllerBase
{
    private readonly IDentistaService _dentistaService;

    public DentistaController(IDentistaService dentistaService)
    {
        _dentistaService = dentistaService;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Dentista>>> GetAll()
    {
        var dentistas = await _dentistaService.GetAllAsync();
        return Ok(dentistas);
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Dentista>> GetById(long id)
    {
        var dentista = await _dentistaService.GetByIdAsync(id);
        if (dentista == null) return NotFound();
        return Ok(dentista);
    }

    [HttpPost]
    public async Task<IActionResult> Create(Dentista dentista)
    {
        await _dentistaService.AddAsync(dentista);
        return CreatedAtAction(nameof(GetById), new { id = dentista.Id }, dentista);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> Update(long id, Dentista dentista)
    {
        if (id != dentista.Id) return BadRequest();
        await _dentistaService.UpdateAsync(dentista);
        return NoContent();
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> Delete(long id)
    {
        await _dentistaService.DeleteAsync(id);
        return NoContent();
    }
}
