﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OdontoSinistro.Domain.Entities;

namespace OdontoSinistro.Application.Interfaces;

public interface IAuditoriaSinistroService
{
    Task<IEnumerable<AuditoriaSinistro>> GetAllAsync();
    Task<AuditoriaSinistro?> GetByIdAsync(long id);
    Task AddAsync(AuditoriaSinistro auditoria);
    Task UpdateAsync(AuditoriaSinistro auditoria);
    Task DeleteAsync(long id);
}
