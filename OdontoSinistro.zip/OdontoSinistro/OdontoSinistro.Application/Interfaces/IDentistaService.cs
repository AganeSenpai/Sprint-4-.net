﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OdontoSinistro.Domain.Entities;

namespace OdontoSinistro.Application.Interfaces;

    public interface IDentistaService
    {
        Task<IEnumerable<Dentista>> GetAllAsync();
        Task<Dentista?> GetByIdAsync(long id);
        Task AddAsync(Dentista dentista);
        Task UpdateAsync(Dentista dentista);
        Task DeleteAsync(long id);
    }

