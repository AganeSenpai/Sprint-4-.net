﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using OdontoSinistro.Application.Interfaces;
using OdontoSinistro.Application.Services;

namespace OdontoSinistro.Application.Extensions;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddScoped<ISinistroService, SinistroService>();
        services.AddScoped<IDentistaService, DentistaService>();
        services.AddScoped<IPacienteService, PacienteService>();
        services.AddScoped<IAuditoriaSinistroService, AuditoriaSinistroService>();
        services.AddScoped<IFuncionarioService, FuncionarioService>();
        services.AddScoped<IEmpresaService, EmpresaService>();

        return services;
    }
}

