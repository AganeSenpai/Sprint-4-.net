﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OdontoSinistro.Application.Services;

public class SentimentoService
{
    public string AnalisarDescricao(string descricao)
    {
        if (descricao.Contains("péssimo") || descricao.Contains("reclamação") || descricao.Contains("erro"))
            return "Negativo";
        if (descricao.Contains("ótimo") || descricao.Contains("satisfeito") || descricao.Contains("excelente"))
            return "Positivo";

        return "Neutro";
    }
}

