﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OdontoSinistro.Application.Interfaces;
using OdontoSinistro.Domain.Entities;
using OdontoSinistro.Domain.Interface;

namespace OdontoSinistro.Application.Services
{
    public class DentistaService : IDentistaService
    {
        private readonly IDentistaRepository _repository;

        public DentistaService(IDentistaRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Dentista>> GetAllAsync() => await _repository.GetAllAsync();
        public async Task<Dentista?> GetByIdAsync(long id) => await _repository.GetByIdAsync(id);
        public async Task AddAsync(Dentista dentista) => await _repository.AddAsync(dentista);
        public async Task UpdateAsync(Dentista dentista) => await _repository.UpdateAsync(dentista);
        public async Task DeleteAsync(long id) => await _repository.DeleteAsync(id);
    }
}

