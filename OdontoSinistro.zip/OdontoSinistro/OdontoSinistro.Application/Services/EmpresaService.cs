﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OdontoSinistro.Application.Interfaces;
using OdontoSinistro.Domain.Entities;
using OdontoSinistro.Domain.Interface;

namespace OdontoSinistro.Application.Services
{
    public class EmpresaService : IEmpresaService
    {
        private readonly IEmpresaRepository _repository;

        public EmpresaService(IEmpresaRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Empresa>> GetAllAsync() => await _repository.GetAllAsync();
        public async Task<Empresa?> GetByIdAsync(long id) => await _repository.GetByIdAsync(id);
        public async Task AddAsync(Empresa empresa) => await _repository.AddAsync(empresa);
        public async Task UpdateAsync(Empresa empresa) => await _repository.UpdateAsync(empresa);
        public async Task DeleteAsync(long id) => await _repository.DeleteAsync(id);
    }
}
