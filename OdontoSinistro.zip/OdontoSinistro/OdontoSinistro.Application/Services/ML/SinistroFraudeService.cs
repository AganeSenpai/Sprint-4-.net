﻿using Microsoft.ML;
using OdontoSinistro.Domain.ML;

public class SinistroFraudeService
{
    private readonly MLContext _mlContext;
    private readonly ITransformer _model;

    public SinistroFraudeService()
    {
        _mlContext = new MLContext();

        var data = _mlContext.Data.LoadFromEnumerable(new[]
        {
            new SinistroFraudeModel { ValorReclamado = 100, TipoProcedimento = "Consulta", EhFraude = false },
            new SinistroFraudeModel { ValorReclamado = 1200, TipoProcedimento = "Implante", EhFraude = true },
            new SinistroFraudeModel { ValorReclamado = 80, TipoProcedimento = "Limpeza", EhFraude = false },
            new SinistroFraudeModel { ValorReclamado = 2000, TipoProcedimento = "Cirurgia", EhFraude = true }
        });

        var pipeline = _mlContext.Transforms.Conversion
            .MapValueToKey("TipoProcedimento")
            .Append(_mlContext.Transforms.Concatenate("Features", "ValorReclamado", "TipoProcedimento"))
            .Append(_mlContext.BinaryClassification.Trainers.SdcaLogisticRegression());

        _model = pipeline.Fit(data);
    }

    public bool PreverFraude(float valor, string tipo)
    {
        var engine = _mlContext.Model.CreatePredictionEngine<SinistroFraudeModel, SinistroFraudePrediction>(_model);
        var prediction = engine.Predict(new SinistroFraudeModel { ValorReclamado = valor, TipoProcedimento = tipo });
        return prediction.EhFraude;
    }
}
