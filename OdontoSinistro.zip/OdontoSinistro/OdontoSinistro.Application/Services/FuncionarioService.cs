﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OdontoSinistro.Application.Interfaces;
using OdontoSinistro.Domain.Entities;
using OdontoSinistro.Domain.Interface;

namespace OdontoSinistro.Application.Services;

public class FuncionarioService : IFuncionarioService
{
    private readonly IFuncionarioRepository _repository;

    public FuncionarioService(IFuncionarioRepository repository)
    {
        _repository = repository;
    }

    public async Task<IEnumerable<Funcionario>> GetAllAsync() => await _repository.GetAllAsync();
    public async Task<Funcionario?> GetByIdAsync(long id) => await _repository.GetByIdAsync(id);
    public async Task AddAsync(Funcionario funcionario) => await _repository.AddAsync(funcionario);
    public async Task UpdateAsync(Funcionario funcionario) => await _repository.UpdateAsync(funcionario);
    public async Task DeleteAsync(long id) => await _repository.DeleteAsync(id);
}
