﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OdontoSinistro.Application.Interfaces;
using OdontoSinistro.Domain.Entities;
using OdontoSinistro.Domain.Interface;

namespace OdontoSinistro.Application.Services
{
    public class AuditoriaSinistroService : IAuditoriaSinistroService
    {
        private readonly IAuditoriaSinistroRepository _repository;

        public AuditoriaSinistroService(IAuditoriaSinistroRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<AuditoriaSinistro>> GetAllAsync() => await _repository.GetAllAsync();
        public async Task<AuditoriaSinistro?> GetByIdAsync(long id) => await _repository.GetByIdAsync(id);
        public async Task AddAsync(AuditoriaSinistro auditoria) => await _repository.AddAsync(auditoria);
        public async Task UpdateAsync(AuditoriaSinistro auditoria) => await _repository.UpdateAsync(auditoria);
        public async Task DeleteAsync(long id) => await _repository.DeleteAsync(id);
    }
}
