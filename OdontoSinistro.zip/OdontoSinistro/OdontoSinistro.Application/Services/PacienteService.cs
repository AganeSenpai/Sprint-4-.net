﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OdontoSinistro.Application.Interfaces;
using OdontoSinistro.Domain.Entities;
using OdontoSinistro.Domain.Interface;

namespace OdontoSinistro.Application.Services
{
    public class PacienteService : IPacienteService
    {
        private readonly IPacienteRepository _repository;

        public PacienteService(IPacienteRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Paciente>> GetAllAsync() => await _repository.GetAllAsync();
        public async Task<Paciente?> GetByIdAsync(long id) => await _repository.GetByIdAsync(id);
        public async Task AddAsync(Paciente paciente) => await _repository.AddAsync(paciente);
        public async Task UpdateAsync(Paciente paciente) => await _repository.UpdateAsync(paciente);
        public async Task DeleteAsync(long id) => await _repository.DeleteAsync(id);
    }
}
