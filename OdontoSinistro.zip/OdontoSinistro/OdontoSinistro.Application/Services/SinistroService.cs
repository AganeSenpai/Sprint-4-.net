﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OdontoSinistro.Application.Interfaces;
using OdontoSinistro.Domain.Entities;
using OdontoSinistro.Domain.Interface;

namespace OdontoSinistro.Application.Services;

public class SinistroService : ISinistroService
{
    private readonly ISinistroRepository _repository;

    public SinistroService(ISinistroRepository repository)
    {
        _repository = repository;
    }

    public async Task<IEnumerable<Sinistro>> GetAllAsync() => await _repository.GetAllAsync();

    public async Task<Sinistro?> GetByIdAsync(long id) => await _repository.GetByIdAsync(id);

    public async Task AddAsync(Sinistro sinistro) => await _repository.AddAsync(sinistro);

    public async Task UpdateAsync(Sinistro sinistro) => await _repository.UpdateAsync(sinistro);

    public async Task DeleteAsync(long id) => await _repository.DeleteAsync(id);
}
