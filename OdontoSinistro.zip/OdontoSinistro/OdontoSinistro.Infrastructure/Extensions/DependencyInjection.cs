﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using OdontoSinistro.Domain.Interface;
using OdontoSinistro.Infrastructure.Context;
using OdontoSinistro.Infrastructure.ExternalServices.Interfaces;
using OdontoSinistro.Infrastructure.ExternalServices.Services;
using OdontoSinistro.Infrastructure.Repositories;

namespace OdontoSinistro.Infrastructure.Extensions;


    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services)
        {
            services.AddScoped<IDentistaRepository, DentistaRepository>();
            services.AddScoped<IPacienteRepository, PacienteRepository>();
            services.AddHttpClient<IViaCepService, ViaCepService>();
            services.AddScoped<ISinistroRepository, SinistroRepository>();
            services.AddScoped<IAuditoriaSinistroRepository, AuditoriaSinistroRepository>();
            services.AddScoped<IFuncionarioRepository, FuncionarioRepository>();
            services.AddScoped<IEmpresaRepository, EmpresaRepository>();

            return services;
        }
    }

