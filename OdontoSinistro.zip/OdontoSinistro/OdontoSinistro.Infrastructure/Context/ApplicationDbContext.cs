﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using global::OdontoSinistro.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using OdontoSinistro.Domain.Entities;
using System.Reflection.Emit;

namespace OdontoSinistro.Infrastructure.Context;

    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        public DbSet<Dentista> Dentistas { get; set; }
        public DbSet<Paciente> Pacientes { get; set; }
        public DbSet<Sinistro> Sinistros { get; set; }
        public DbSet<AuditoriaSinistro> Auditorias { get; set; }
        public DbSet<Funcionario> Funcionarios { get; set; }
        public DbSet<Empresa> Empresas { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            base.OnModelCreating(modelBuilder);
        }
    }
