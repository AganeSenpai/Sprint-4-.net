﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http.Json;
using OdontoSinistro.Infrastructure.ExternalServices.Interfaces;

namespace OdontoSinistro.Infrastructure.ExternalServices.Services;

public class ViaCepService : IViaCepService
{
    private readonly HttpClient _httpClient;

    public ViaCepService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    public async Task<string?> GetEnderecoPorCepAsync(string cep)
    {
        var response = await _httpClient.GetFromJsonAsync<ViaCepResponse>($"https://viacep.com.br/ws/{cep}/json/");
        return response != null
            ? $"{response.Logradouro}, {response.Bairro}, {response.Localidade} - {response.Uf}"
            : null;
    }

    private class ViaCepResponse
    {
        public string Logradouro { get; set; }
        public string Bairro { get; set; }
        public string Localidade { get; set; }
        public string Uf { get; set; }
    }
}
