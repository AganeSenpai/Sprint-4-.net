﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OdontoSinistro.Infrastructure.ExternalServices.Interfaces;

public interface IViaCepService
{
    Task<string?> GetEnderecoPorCepAsync(string cep);
}

