﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OdontoSinistro.Domain.Entities;
using OdontoSinistro.Domain.Interface;
using OdontoSinistro.Infrastructure.Context;

namespace OdontoSinistro.Infrastructure.Repositories;

public class EmpresaRepository : GenericRepository<Empresa>, IEmpresaRepository
{
    public EmpresaRepository(ApplicationDbContext context) : base(context) { }
}
