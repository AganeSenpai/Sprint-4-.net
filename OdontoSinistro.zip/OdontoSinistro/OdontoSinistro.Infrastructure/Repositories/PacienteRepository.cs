﻿using OdontoSinistro.Domain.Entities;
using OdontoSinistro.Domain.Interface;
using OdontoSinistro.Infrastructure.Context;

namespace OdontoSinistro.Infrastructure.Repositories;

public class PacienteRepository : GenericRepository<Paciente>, IPacienteRepository
{
    public PacienteRepository(ApplicationDbContext context) : base(context) { }
}
