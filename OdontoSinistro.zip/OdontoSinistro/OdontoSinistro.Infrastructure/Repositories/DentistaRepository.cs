﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OdontoSinistro.Domain.Entities;
using OdontoSinistro.Domain.Interface;
using OdontoSinistro.Infrastructure.Context;

namespace OdontoSinistro.Infrastructure.Repositories;

public class DentistaRepository : GenericRepository<Dentista>, IDentistaRepository
{
    public DentistaRepository(ApplicationDbContext context) : base(context) { }
}
