using Xunit;
using Moq;
using OdontoSinistro.Domain.Interface;
using OdontoSinistro.Application.Services;
using OdontoSinistro.Domain.Entities;

namespace OdontoSinistro.Tests;

public class SinistroServiceTests
{
    private readonly Mock<ISinistroRepository> _mockRepo;
    private readonly SinistroService _service;

    public SinistroServiceTests()
    {
        _mockRepo = new Mock<ISinistroRepository>();
        _service = new SinistroService(_mockRepo.Object);
    }

    [Fact]
    public async Task AddAsync_DeveChamarRepositorioComEntidadeValida()
    {
        var sinistro = new Sinistro
        {
            Id = 1,
            Descricao = "Consulta de rotina",
            ValorReclamado = 100
        };

        await _service.AddAsync(sinistro);
        _mockRepo.Verify(r => r.AddAsync(sinistro), Times.Once);
    }
}
