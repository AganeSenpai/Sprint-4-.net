﻿using Microsoft.EntityFrameworkCore;
using OdontoSinistro.Domain.Entities;
using OdontoSinistro.Infrastructure.Context;
using OdontoSinistro.Infrastructure.Repositories;
using Xunit;

namespace OdontoSinistro.Tests
{
    public class SinistroRepositoryTests
    {
        private readonly ApplicationDbContext _context;
        private readonly SinistroRepository _repository;

        public SinistroRepositoryTests()
        {
            var options = new DbContextOptionsBuilder<ApplicationDbContext>()
                .UseInMemoryDatabase(databaseName: "DbTest")
                .Options;

            _context = new ApplicationDbContext(options);
            _repository = new SinistroRepository(_context);
        }

        [Fact]
        public async Task AddAsync_DeveAdicionarSinistro()
        {
            var sinistro = new Sinistro
            {
                Descricao = "Consulta",
                ValorReclamado = 200
            };

            await _repository.AddAsync(sinistro);
            var result = await _repository.GetByIdAsync(sinistro.Id);

            Assert.NotNull(result);
            Assert.Equal("Consulta", result.Descricao);
        }
    }
}
