﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OdontoSinistro.Domain.Interface;
using OdontoSinistro.Domain.Entities;

public interface IDentistaRepository
{
    Task<IEnumerable<Dentista>> GetAllAsync();
    Task<Dentista?> GetByIdAsync(long id);
    Task AddAsync(Dentista dentista);
    Task UpdateAsync(Dentista dentista);
    Task DeleteAsync(long id);
}
