﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OdontoSinistro.Domain.Entities;

public class AuditoriaSinistro
{
    public long Id { get; set; }
    public DateTime DataAuditoria { get; set; }
    public string Resultado { get; set; } = string.Empty;

    public long IdFuncionario { get; set; }
    public Funcionario Funcionario { get; set; }

    public long IdSinistro { get; set; }
    public Sinistro Sinistro { get; set; }
}

