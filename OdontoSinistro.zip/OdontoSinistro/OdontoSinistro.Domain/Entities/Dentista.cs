﻿namespace OdontoSinistro.Domain.Entities;
public class Dentista
{
    public long Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public string Cpf { get; set; } = string.Empty;
    public string Cro { get; set; } = string.Empty;
    public string Especialidade { get; set; } = string.Empty;
    public string Endereco { get; set; } = string.Empty;

    public ICollection<Paciente> Pacientes { get; set; }
}
