﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OdontoSinistro.Domain.Entities;

public class Paciente
{
    public long Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public string Cpf { get; set; } = string.Empty;
    public DateTime DataNascimento { get; set; }

    public long IdDentista { get; set; }
    public Dentista Dentista { get; set; }

    public ICollection<Sinistro> Sinistros { get; set; }
}
