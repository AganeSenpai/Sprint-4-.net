﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OdontoSinistro.Domain.Entities;

public class Sinistro
{
    public long Id { get; set; }
    public DateTime DataSinistro { get; set; }
    public string Descricao { get; set; } = string.Empty;
    public decimal ValorReclamado { get; set; }

    public long IdPaciente { get; set; }
    public Paciente Paciente { get; set; }

    public ICollection<AuditoriaSinistro> Auditorias { get; set; }
}

