﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OdontoSinistro.Domain.Entities;

public class Funcionario
{
    public long Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public string Cpf { get; set; } = string.Empty;
    public string Cargo { get; set; } = string.Empty;
    public DateTime DataAdmissao { get; set; }

    public long IdEmpresa { get; set; }
    public Empresa Empresa { get; set; }

    public ICollection<AuditoriaSinistro> Auditorias { get; set; }
}
