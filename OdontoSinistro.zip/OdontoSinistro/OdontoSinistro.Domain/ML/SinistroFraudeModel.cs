﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OdontoSinistro.Domain.ML;
public class SinistroFraudeModel
{
    public float ValorReclamado { get; set; }
    public string TipoProcedimento { get; set; }
    public bool EhFraude { get; set; }
}

