﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ML.Data;

namespace OdontoSinistro.Domain.ML;


public class SinistroFraudePrediction
{
    [ColumnName("PredictedLabel")]
    public bool EhFraude { get; set; }
}

